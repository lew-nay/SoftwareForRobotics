// generated from rosidl_generator_c/resource/idl.h.em
// with input from cooing_code_interfaces:msg/TaskSpacePose.idl
// generated code does not contain a copyright notice

#ifndef COOING_CODE_INTERFACES__MSG__TASK_SPACE_POSE_H_
#define COOING_CODE_INTERFACES__MSG__TASK_SPACE_POSE_H_

#include "cooing_code_interfaces/msg/detail/task_space_pose__struct.h"
#include "cooing_code_interfaces/msg/detail/task_space_pose__functions.h"
#include "cooing_code_interfaces/msg/detail/task_space_pose__type_support.h"

#endif  // COOING_CODE_INTERFACES__MSG__TASK_SPACE_POSE_H_
