// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef COOING_CODE_INTERFACES__MSG__TASK_SPACE_POSE_HPP_
#define COOING_CODE_INTERFACES__MSG__TASK_SPACE_POSE_HPP_

#include "cooing_code_interfaces/msg/detail/task_space_pose__struct.hpp"
#include "cooing_code_interfaces/msg/detail/task_space_pose__builder.hpp"
#include "cooing_code_interfaces/msg/detail/task_space_pose__traits.hpp"

#endif  // COOING_CODE_INTERFACES__MSG__TASK_SPACE_POSE_HPP_
