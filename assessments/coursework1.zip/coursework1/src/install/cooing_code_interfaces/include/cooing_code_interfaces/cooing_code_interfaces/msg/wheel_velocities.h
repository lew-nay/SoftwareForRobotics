// generated from rosidl_generator_c/resource/idl.h.em
// with input from cooing_code_interfaces:msg/WheelVelocities.idl
// generated code does not contain a copyright notice

#ifndef COOING_CODE_INTERFACES__MSG__WHEEL_VELOCITIES_H_
#define COOING_CODE_INTERFACES__MSG__WHEEL_VELOCITIES_H_

#include "cooing_code_interfaces/msg/detail/wheel_velocities__struct.h"
#include "cooing_code_interfaces/msg/detail/wheel_velocities__functions.h"
#include "cooing_code_interfaces/msg/detail/wheel_velocities__type_support.h"

#endif  // COOING_CODE_INTERFACES__MSG__WHEEL_VELOCITIES_H_
