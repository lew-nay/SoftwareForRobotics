// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef COOING_CODE_INTERFACES__MSG__WHEEL_VELOCITIES_HPP_
#define COOING_CODE_INTERFACES__MSG__WHEEL_VELOCITIES_HPP_

#include "cooing_code_interfaces/msg/detail/wheel_velocities__struct.hpp"
#include "cooing_code_interfaces/msg/detail/wheel_velocities__builder.hpp"
#include "cooing_code_interfaces/msg/detail/wheel_velocities__traits.hpp"

#endif  // COOING_CODE_INTERFACES__MSG__WHEEL_VELOCITIES_HPP_
