// generated from rosidl_generator_c/resource/idl.h.em
// with input from cooing_code_interfaces:srv/TurnRobotOff.idl
// generated code does not contain a copyright notice

#ifndef COOING_CODE_INTERFACES__SRV__TURN_ROBOT_OFF_H_
#define COOING_CODE_INTERFACES__SRV__TURN_ROBOT_OFF_H_

#include "cooing_code_interfaces/srv/detail/turn_robot_off__struct.h"
#include "cooing_code_interfaces/srv/detail/turn_robot_off__functions.h"
#include "cooing_code_interfaces/srv/detail/turn_robot_off__type_support.h"

#endif  // COOING_CODE_INTERFACES__SRV__TURN_ROBOT_OFF_H_
