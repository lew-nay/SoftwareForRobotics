// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef COOING_CODE_INTERFACES__SRV__TURN_ROBOT_OFF_HPP_
#define COOING_CODE_INTERFACES__SRV__TURN_ROBOT_OFF_HPP_

#include "cooing_code_interfaces/srv/detail/turn_robot_off__struct.hpp"
#include "cooing_code_interfaces/srv/detail/turn_robot_off__builder.hpp"
#include "cooing_code_interfaces/srv/detail/turn_robot_off__traits.hpp"

#endif  // COOING_CODE_INTERFACES__SRV__TURN_ROBOT_OFF_HPP_
