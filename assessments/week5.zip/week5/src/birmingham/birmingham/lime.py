import rclpy
from rclpy.node import Node
from rclpy.task import Future

from example_interfaces.srv import Trigger


class LimeNode(Node):
    def __init__(self):
        super().__init__('lime_node')

        self.service_client = self.create_client(
            srv_type=Trigger,
            srv_name='/calibrate'
        )

        while not self.service_client.wait_for_service(timeout_sec=3.0):
            self.get_logger().info('unavailable')

        self.future: Future = None

        timer_period: float = 0.5
        self.timer = self.create_timer(
            timer_period_sec=timer_period,
            callback=self.timer_callback
        )

    def timer_callback(self):
        request = Trigger.Request()

        if self.future is not None and not self.future.done():
            self.future.cancel()
            self.get_logger().info('Future service cancelled')

        self.future = self.service_client.call_async(request)
        self.future.add_done_callback(self.process_response)

    def process_response(self, future: Future):
        response = future.result()
        if response is not None:
            self.get_logger().info(f'{response.message}')


def main(args=None):
    try:
        rclpy.init(args=args)

        lime_node = LimeNode()

        rclpy.spin(lime_node)
    except KeyboardInterrupt:
        pass
    except Exception as e:
        print(e)


if __name__ == '__main__':
    main()
