from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    return LaunchDescription([
        Node(
            package='package_c',
            executable='node_c',
            name='meditate_node',
            parameters=[{
                "parameter_string": "sweetness",
                "parameter_float": -75.0,
            }]
        )
    ])