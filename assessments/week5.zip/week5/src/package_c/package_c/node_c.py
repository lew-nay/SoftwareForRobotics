import rclpy
from rclpy.node import Node

class MurilosConfigurableNode(Node):
    """A configurable node for week 5's assessment."""

    def __init__(self):
        super().__init__('murilos_configurable_node')

        # One-off parameters
        self.declare_parameter('parameter_string', 'undefined')
        self.declare_parameter('parameter_float', 0.0)

        self.timer = self.create_timer(0.5, self.timer_callback)

    def timer_callback(self):
        """Method that is periodically called by the timer."""

        parameter_string: str = self.get_parameter('parameter_string').get_parameter_value().string_value
        parameter_float: float = self.get_parameter('parameter_float').get_parameter_value().double_value

        self.get_logger().info(f"string {parameter_string} and float {parameter_float}")


def main(args=None):
    """
    The main function.
    :param args: Not used directly by the user, but used by ROS2 to configure
    certain aspects of the Node.
    """
    try:
        rclpy.init(args=args)

        node = MurilosConfigurableNode()

        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    except Exception as e:
        print(e)


if __name__ == '__main__':
    main()