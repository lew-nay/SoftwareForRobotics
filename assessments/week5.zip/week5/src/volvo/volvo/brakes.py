from example_interfaces.srv import Trigger
import rclpy
from rclpy.node import Node


class CalibrateNode(Node):
    def __init__(self):
        super().__init__('service_node')

        self.service_server = self.create_service(
            srv_type=Trigger,
            srv_name='/calibrate',
            callback=self.service_callback
        )

    def service_callback(self,
                         request: Trigger.Request,
                         response: Trigger.Response) -> Trigger.Response:
        success: bool = True
        message: str = 'trust'

        response.success = success
        response.message = message

        return response

def main(args=None):
    try:
        rclpy.init(args=args)

        calibrate_node = CalibrateNode()

        rclpy.spin(calibrate_node)
    except KeyboardInterrupt:
        pass
    except Exception as e:
        print(e)


if __name__ == '__main__':
    main()
